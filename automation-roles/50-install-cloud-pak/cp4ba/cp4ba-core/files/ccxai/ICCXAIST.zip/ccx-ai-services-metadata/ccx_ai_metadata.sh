#!/bin/bash

# Wrapper script to simplify running PopManager to populate metadata for Report/Section
# MUST modify action, xml_file and properties_file
# Usage: ./ccx_ai_metadata.sh [action] [xml_file] [properties_file]
# Example: ./ccx_ai_metadata.sh create CE_metadata.xml ECMPopulation.properties
# Example: ./ccx_ai_metadata.sh insert MessageLoader.xml ECMPopulation.properties
# Example: ./ccx_ai_metadata.sh clean_data ECMPopulation.properties
# Example: ./ccx_ai_metadata.sh clean_all ECMPopulation.properties

# Set JAVA_HOME if not already set
if [ -z "$JAVA_HOME" ]; then
    export JAVA_HOME=/Library/Java/JavaVirtualMachines/adoptopenjdk-8.jdk/Contents/Home
fi

# Set project root (script location)
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
LIB_DIR=$PROJECT_ROOT/lib

# Build classpath from all jars in lib directory
CLASSPATH=""
for jar in "$LIB_DIR"/*.jar; do
    if [ -f "$jar" ]; then
        if [ -z "$CLASSPATH" ]; then
            CLASSPATH="$jar"
        else
            CLASSPATH="$CLASSPATH:$jar"
        fi
    fi
done

# Set Java options
JAVA_OPTS="$JAVA_OPTS -Dfile.encoding=UTF-8"
JAVA_OPTS="$JAVA_OPTS -Dstdout.encoding=UTF-8"
JAVA_OPTS="$JAVA_OPTS -Dstderr.encoding=UTF-8"

# Default parameters
ACTION="${1:-create}"
XML_FILE="${2:-MetaData.xml}"
PROPERTIES_FILE="${3:-ECMPopulation.properties}"

# Determine which Java class to run based on ACTION
case "$ACTION" in
    create)
        MAIN_CLASS="com.ibm.ecmce.app.CEMetadataCreator"
        XML_FILE="CE_metadata.xml"
        ;;
    insert)
        MAIN_CLASS="com.ibm.ecmce.app.RsMessageLoader"
        XML_FILE="MessageLoader.xml"
        ;;
    clean_data)
        MAIN_CLASS="com.ibm.ecmce.app.RsMessageCleaner"
        XML_FILE="data"
        ;;
    clean_all)
        MAIN_CLASS="com.ibm.ecmce.app.RsMessageCleaner"
        XML_FILE="all"
        ;;
    *)
        echo "Error: Invalid ACTION parameter: $ACTION"
        echo "Valid actions are: create, insert, clean_data, clean_all"
        exit 1
        ;;
esac

echo "=========================================="
echo "Running with ACTION: $ACTION"
echo "Main Class: $MAIN_CLASS"
echo "XML File or Clean type: $XML_FILE"
echo "Properties File: $PROPERTIES_FILE"
echo "=========================================="

# Run the tool
"$JAVA_HOME/bin/java" $JAVA_OPTS -classpath "$CLASSPATH" \
    "$MAIN_CLASS" \
    "$XML_FILE" \
    "$PROPERTIES_FILE"

# Capture exit code
EXIT_CODE=$?

echo "=========================================="
echo "PopManager finished with exit code: $EXIT_CODE"
echo "=========================================="

exit $EXIT_CODE
