importPackage(Packages.java.lang);
importPackage(Packages.com.filenet.api.action);
importPackage(Packages.com.filenet.api.core);
importPackage(Packages.com.filenet.api.constants);

function preprocessObjectChange(sourceObj)
{
   try {
      // Check if this is a create action
      var isCreate = false;
      var actions = sourceObj.getPendingActions();
      for (var i = 0; i < actions.length && !isCreate; i++ )
      {
         if ( actions[i] instanceof Create)
            isCreate = true;
      }
      
      if ( !isCreate ) return false;
      var userThread = sourceObj;
      // Fetch the current user
      var currentUser = Factory.User.fetchCurrent(userThread.getObjectStore().getConnection(), null);
      // Set the RsUser property
      userThread.getProperties().putObjectValue("RsUser", currentUser);
      return true;
   }
   catch (e) {
      throw new RuntimeException(e);
   }
}

